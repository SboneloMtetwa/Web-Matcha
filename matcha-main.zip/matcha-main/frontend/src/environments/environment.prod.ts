export const environment = {
	production: true,
	server: 'http://localhost:1942/rest'
};

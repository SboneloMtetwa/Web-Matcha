export enum NotificationTypeEnum {
	LIKE = 'LIKE',
	LIKED_BACK = 'LIKED_BACK',
	UNLIKED = 'UNLIKED',
	VIEWED = 'VIEWED',
	MESSAGE = 'MESSAGE',
}

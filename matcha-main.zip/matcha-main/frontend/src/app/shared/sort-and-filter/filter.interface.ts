export interface IFilter {
	fame: number[];
	distance: number[];
	commonTags: number[];
	birthday: string[];
}

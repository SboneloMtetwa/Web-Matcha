export interface ITag {
	id: number;
	value: string;
}

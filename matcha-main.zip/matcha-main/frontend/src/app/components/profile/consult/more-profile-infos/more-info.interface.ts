export interface IMoreInfos {
  visits: string[];
  likes: string[];
  fameRating: number;
}

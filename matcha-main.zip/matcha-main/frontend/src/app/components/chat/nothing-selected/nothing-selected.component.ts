import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-nothing-selected',
	templateUrl: './nothing-selected.component.html',
})
export class NothingSelectedComponent implements OnInit {

	constructor() {
	}

	ngOnInit(): void {
	}

}

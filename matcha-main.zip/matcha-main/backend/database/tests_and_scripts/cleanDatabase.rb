require __dir__ + '/../databaseManager.rb'

db = DatabaseManager.new

db.deleteDatabase

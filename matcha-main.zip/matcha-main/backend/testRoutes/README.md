# Launch tester
node appRoutesTest.js
